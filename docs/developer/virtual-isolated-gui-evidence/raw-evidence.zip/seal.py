import hashlib
import json
from pathlib import Path
import shutil
import subprocess
import zipfile

ROOT = Path.cwd()
AUDIT = ROOT / 'target/b3b5-admission-audit'
DEST = ROOT / 'docs/developer/virtual-isolated-gui-evidence'
DEST.mkdir(exist_ok=False)
HEAD = 'd96111f488d8535c294879e767832d537219108a'
QUALIFIED = 'f444da9322e9db75d9bcb7e6ae908833a6a17b67'
REVIEWED = '2dd4af1edc7f6ec0bb09ca9a4d28fc3c56670a1c'
BASE = '1890fafb15a53c4517a3dc7295d74d1a1756b5ea'
logs = []


def run(*args):
    result = subprocess.run(args, capture_output=True, check=False)
    blob = args[:2] == ('git', 'show') and len(args) == 3 and ':' in args[2]
    logs.append({'argv': list(args), 'exit_code': result.returncode,
                 'stdout': None if blob else result.stdout.decode('utf-8', errors='replace'),
                 'blob_bytes': len(result.stdout) if blob else None,
                 'blob_sha256': hashlib.sha256(result.stdout).hexdigest() if blob else None,
                 'stderr': result.stderr.decode('utf-8', errors='replace')})
    result.check_returncode()
    return result.stdout


def write(path, value):
    path.write_text(json.dumps(value, indent=2, ensure_ascii=True) + '\n',
                    encoding='utf-8', newline='\n')


assert run('git', 'rev-parse', 'HEAD').decode().strip() == HEAD
assert run('git', 'show', '-s', '--format=%P', HEAD).decode().split() == [BASE, REVIEWED]
merged = json.loads(run('gh', 'pr', 'view', '42', '--repo',
                       'alexandervolkov1/lab-runtime', '--json',
                       'state,isDraft,mergeCommit,headRefOid,baseRefOid,url'))
assert merged['state'] == 'MERGED' and not merged['isDraft']
assert merged['mergeCommit']['oid'] == HEAD
assert merged['headRefOid'] == REVIEWED and merged['baseRefOid'] == BASE
write(AUDIT / 'merged-pr.json', merged)
paths = run('git', 'diff', '--name-only', QUALIFIED, REVIEWED).decode().splitlines()
assert len(paths) == 42
assert all(p.startswith('docs/developer/isolated-renderer-lifecycle-memory') for p in paths)
assert not run('git', 'diff', '--name-only', QUALIFIED, HEAD, '--',
               'apps', 'crates', 'scripts', 'Cargo.toml', 'Cargo.lock').strip()

qualified_path = 'docs/developer/isolated-renderer-lifecycle-memory-evidence/windows-profile.json'
qualified_bytes = run('git', 'show', HEAD + ':' + qualified_path)
qualified = json.loads(qualified_bytes)
(AUDIT / 'qualified-windows-profile.json').write_bytes(qualified_bytes)
actual = json.loads((AUDIT / 'actual-windows-profile.json').read_text(encoding='utf-8-sig'))
expected_cpu = qualified['cpu']['Name'].strip()
expected_gpu = qualified['gpu']['Name'].strip()
expected_driver = qualified['gpu']['DriverVersion']
checks = {
    'os_version': actual['os']['Version'] == qualified['os']['Version'],
    'os_caption': actual['os']['Caption'] == qualified['os']['Caption'],
    'os_architecture': actual['os']['OSArchitecture'] == qualified['os']['OSArchitecture'],
    'toolchain': actual['toolchain'] == qualified['toolchain'],
    'cargo': actual['cargo'] == qualified['cargo'],
    'cpu': len(actual['cpu']) == 1 and actual['cpu'][0]['Name'].strip() == expected_cpu,
    'installed_qualified_gpu_driver': any(
        gpu['Name'].strip() == expected_gpu and gpu['DriverVersion'] == expected_driver
        for gpu in actual['gpu']),
}
assert not checks['cpu'] and not checks['installed_qualified_gpu_driver']
preflight = {
    'verdict': 'BLOCKED', 'kind': 'read-only environment preflight; no executable admission gate',
    'checks': checks, 'qualified_profile_path': qualified_path,
    'qualified_profile_git_sha256': hashlib.sha256(qualified_bytes).hexdigest(),
    'diagnostic': 'Qualified fixed AMD CPU/GPU/driver profile unavailable; experimental execution refused before implementation.',
    'accepted_experimental_C_bytes': 234881024, 'C_installed': False, 'C_raised': False,
    'experimental_host_implemented': False, 'fixture_owned_launcher_implemented': False,
    'task_launched_runtime': False, 'task_launched_workbench': False,
    'task_launched_renderer': False, 'actual_gl_context_created': False,
    'runtime_connections': None, 'runtime_scopes': None, 'query_baseline': None,
    'display_fault_query_delta': None, 'display_fault_operation_delta': None,
    'framebuffer': None, 'process_commit_peak': None, 'job_commit_peak': None,
    'own_gpu_objects': None, 'cpu_preview': None, 'parsed_document': None,
    'selected_read_view': None, 'ipc_credits': None, 'original_process_ipc_retirement': None,
    'activation_qualified': False,
}
write(DEST / 'preflight.json', preflight)

inventory = json.loads(run('git', 'show', HEAD +
    ':docs/developer/isolated-renderer-lifecycle-memory-evidence/source-inputs.json'))
rows = []
for entry in inventory['files']:
    path = entry['path']
    canonical = run('git', 'show', HEAD + ':' + path)
    digest = hashlib.sha256(canonical).hexdigest()
    assert digest == entry['git_sha256'], path
    rows.append({'path': path, 'qualified_and_merge_git_sha256': digest,
                 'current_worktree_raw_sha256': hashlib.sha256((ROOT / path).read_bytes()).hexdigest()})
assert len(rows) == 359
write(DEST / 'source-equivalence.json', {
    'qualified_source': QUALIFIED, 'reviewed_head': REVIEWED, 'merge_source': HEAD,
    'compared_files': len(rows), 'mismatches': [],
    'scope': 'canonical source/build/fixture bytes only; no B3B5 execution qualification',
    'files': rows})

binaries = []
for profile, directory in [('dev', 'debug'), ('release', 'release')]:
    for role in ['lab-runtime', 'lab-workbench', 'lab-native-child']:
        path = Path('target') / directory / (role + '.exe')
        exists = path.is_file()
        binaries.append({'profile': profile, 'role': role, 'path': path.as_posix(),
                         'exists': exists, 'bytes': path.stat().st_size if exists else None,
                         'sha256': hashlib.sha256(path.read_bytes()).hexdigest() if exists else None,
                         'built_by_this_task': False, 'executed_by_this_task': False,
                         'build_source_head': None,
                         'qualification': 'inspection-only; no source attestation or B3B5 run'})
write(DEST / 'binary-identities.json', binaries)

for name in ['premerge.json', 'merge-api.json', 'merge-verified.json', 'actual-windows-profile.json']:
    shutil.copyfile(AUDIT / name, DEST / name)
write(AUDIT / 'commands.json', logs)
write(AUDIT / 'preflight.json', preflight)
write(AUDIT / 'collection-notes.json', {
    'initial_ready_command': 'gh pr ready 42 --repo alexandervolkov1/lab-runtime',
    'deviation': 'Ready succeeded. Printing its Unicode check mark to a cp1251 Python stdout raised UnicodeEncodeError before merge. A fresh remote HEAD/base/Ready check preceded the one SHA-guarded merge.',
    'profile_collection': 'Read-only Get-CimInstance Win32_OperatingSystem/Win32_Processor/Win32_VideoController, rustc -Vv, cargo -V, git rev-parse HEAD, git branch --show-current, Get-Process -Name lab-runtime,lab-workbench,lab-native-child.',
    'profile_collection_exit_note': 'A following rg --files target -g lab-native-child.exe search found no child executable (exit 1); profile JSON had already been written successfully.',
    'fmt': {'command': ['cargo', 'fmt', '--all', '--', '--check'],
            'exit_code': 0, 'stdout': '', 'stderr': '', 'wall_time_seconds': 1.6296493},
    'heavy_gates': 'Not run: documentation/evidence-only task; B3B5 native qualification refused on mismatched hardware/driver.',
})
raw = [p for p in AUDIT.iterdir() if p.is_file() and p.suffix in ['.json', '.py']]
manifest = []
with zipfile.ZipFile(DEST / 'raw-evidence.zip', 'w', zipfile.ZIP_DEFLATED) as archive:
    for path in sorted(raw):
        data = path.read_bytes()
        archive.writestr(path.name, data)
        manifest.append({'member': path.name, 'bytes': len(data), 'sha256': hashlib.sha256(data).hexdigest()})
write(DEST / 'raw-manifest.json', manifest)
print(json.dumps({'verdict': 'BLOCKED', 'checks': checks, 'source_hashes_verified': len(rows),
                  'raw_archive_members': len(manifest), 'new_binaries': 0}))
