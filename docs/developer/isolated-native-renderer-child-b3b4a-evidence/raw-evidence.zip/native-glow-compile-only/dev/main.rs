//! Standalone native rendering qualification; no Runtime connection.
#![deny(unsafe_code)]
#![allow(dead_code, unused_imports)]
#[path = "D:/rust_projects/lab-runtime/apps/lab-workbench/src/client/mod.rs"] mod client;
#[path = "D:/rust_projects/lab-runtime/apps/lab-workbench/src/dispatcher.rs"] mod dispatcher;
#[path = "D:/rust_projects/lab-runtime/apps/lab-workbench/src/external.rs"] mod external;
#[path = "D:/rust_projects/lab-runtime/apps/lab-workbench/src/model/mod.rs"] mod model;
#[path = "D:/rust_projects/lab-runtime/apps/lab-workbench/src/ownership.rs"] mod ownership;
#[path = "D:/rust_projects/lab-runtime/apps/lab-workbench/src/presentation/mod.rs"] mod presentation;
#[path = "D:/rust_projects/lab-runtime/apps/lab-workbench/src/recovery/mod.rs"] mod recovery;
#[path = "D:/rust_projects/lab-runtime/apps/lab-workbench/src/storage.rs"] mod storage;
#[path = "D:/rust_projects/lab-runtime/apps/lab-workbench/src/gui/rebuild.rs"] mod rebuild;
mod gui { #[path = "D:/rust_projects/lab-runtime/apps/lab-workbench/src/gui/readonly_v2/mod.rs"] pub(crate) mod readonly_v2; }
use gui::readonly_v2;
#[path = "D:/rust_projects/lab-runtime/apps/lab-workbench/src/gui/readonly_v2/plot_fixtures.rs"] mod plot_fixtures;
#[path = "D:/rust_projects/lab-runtime/scripts/support/native-glow-smoke.rs"] mod native_glow;
fn main() { native_glow::run(); }