import ast,csv,hashlib,io,json,pathlib,re,subprocess
root=pathlib.Path(__file__).resolve().parents[2]
base=root/'target/b3b4a-qualification'
out=base/'attempt-2'
records=json.loads((out/'gates.json').read_bytes())
assert len(records)==34 and all(r['exit_code']==0 for r in records)
source=json.loads((out/'source-inputs.json').read_bytes())
head=source['source_head']
assert all(r['source_head']==head for r in records)
for item in source['files']:
    assert hashlib.sha256((root/item['path']).read_bytes()).hexdigest()==item['raw_sha256']
    assert hashlib.sha256(subprocess.check_output(['git','show',f"HEAD:{item['path']}"],cwd=root)).hexdigest()==item['git_sha256']
for record in records:
    assert hashlib.sha256((out/(record['name']+'.txt')).read_bytes()).hexdigest()==record['log_sha256']
inventories=[]
profiles=[]
for profile in ['dev','release']:
    def text(s): return (out/(profile+'-'+s+'.txt')).read_text(encoding='utf-8-sig')
    tests=[line for line in text('inventory').splitlines() if line.endswith(': test')]
    inventories.append(tests)
    assert len(tests)==566
    def result(s):
        matches=re.findall(r'test result: ok\. (\d+) passed; (\d+) failed; (\d+) ignored;',text(s))
        assert matches,(s,matches)
        assert all(int(row[1])==0 for row in matches)
        # Full suites include nested process-fixture test summaries. The final
        # summary is the outer Workbench inventory; the library capsule adds a
        # separate zero-doctest summary, so aggregate that package only.
        chosen=matches if s=='os-capsule' else matches[-1:]
        passed=sum(int(row[0]) for row in chosen); failed=sum(int(row[1]) for row in chosen); ignored=sum(int(row[2]) for row in chosen); assert failed==0
        return {'passed':passed,'ignored':ignored}
    summary={s:result(s) for s in ['full','handoff-provider','parent-supervisor','virtual','native-supervisor','native-ipc','os-capsule']}
    assert summary['full']=={'passed':522,'ignored':44}
    assert summary['handoff-provider']['passed']==16
    assert summary['virtual']['passed']==13
    assert summary['native-supervisor']['passed']==7
    assert summary['native-ipc']['passed']==22
    assert text('cpu-preview').count('Ownership compile-fail PASS:')==10
    assert 'B2B2 standalone compile and Clippy PASS; no GPU execution' in text('standalone-compile')
    assert 'non-Send E0277 and protected-policy E0453 rejection PASS' in text('native-capsule')
    views=re.findall(r'SELECTED_PROVIDER accounted_view_bytes=(\d+) fixed_bytes=(\d+) target_string_ceiling=(\d+) encoded_copy_bytes=0',text('handoff-provider'))
    assert views==[('9134','9080','131072')]
    assert 'HANDOFF actual_admitted_peak=1 calls=2 constructed=2 dropped=2 slots=4' in text('handoff-provider')
    assert 'NO_GPU persistent_parsed_documents=0 actual_admitted_peak=1 encoded_slots=4' in text('handoff-provider')
    assert 'PARENT_NATIVE mode=handoff ' in text('native-ipc')
    assert 'PARENT_NATIVE mode=handoff-crash ' in text('native-ipc')
    assert 'original_ipc_baseline=true' in text('native-ipc')
    smoke=json.loads(text('v1-smoke').strip().splitlines()[-1])
    assert smoke['status']=='pass'
    path=pathlib.Path(smoke['result'])
    native=json.loads(path.read_bytes())
    assert native['connections']==2
    assert native['mutation_submissions']==1 and native['status_submissions']==0 and native['repeat_mutation_submissions']==0
    assert native['binary_source_head']==head
    profiles.append({'profile':profile,'tests':summary,'borrowing_checks':10,'selected_view_accounted_bytes':9134,'selected_fixed_bytes':9080,'max_live_admitted_documents':1,'encoded_slots':4,'strict_v1_result':str(path),'strict_v1_connections':2,'strict_v1_mutations':1,'strict_v1_status_retry':0})
assert inventories[0]==inventories[1]
(out/'test-inventory.txt').write_text('\n'.join(inventories[0])+'\n',encoding='utf-8')
comparisons=[]
old=json.loads((root/'docs/developer/private-readonly-ipc-evidence/cpu-comparison.json').read_bytes())
for item in old:
    if 'reference' not in item: continue
    current=root/f"target/v2-renderer-allocation-probe/{item['profile']}/{item['suite']}.txt"
    previous=root/item['reference']
    def rows(path):
        lines=path.read_text(encoding='utf-8-sig').splitlines()
        first=next(i for i,line in enumerate(lines) if line.startswith('scenario,'))
        parsed=list(csv.DictReader(lines[first:]))
        return [row for row in parsed if row.get('status') is not None or row.get('result') is not None]
    a=rows(current); b=rows(previous)
    assert len(a)==len(b)==item['cases'],item
    for left,right in zip(a,b):
        assert {k:v for k,v in left.items() if k!='wait_calls'}=={k:v for k,v in right.items() if k!='wait_calls'},(item,left,right)
    maximum=max(int(row['accounted']) for row in a)
    assert maximum==item['max_accounted']
    comparisons.append({'profile':item['profile'],'suite':item['suite'],'rows':len(a),'max_accounted':maximum,'reference':item['reference'],'comparison':'all columns exact except scheduling-dependent wait_calls','raw_sha256':hashlib.sha256(current.read_bytes()).hexdigest()})
(out/'cpu-comparison.json').write_text(json.dumps(comparisons,indent=2)+'\n',encoding='utf-8')
summary={'source_head':head,'gate_count':len(records),'profiles':profiles,'test_inventory_identical':566,'source_inputs_verified':len(source['files']),'cpu_max_accounted':max(c['max_accounted'] for c in comparisons),'cpu_allowance':8388608,'new_renderer_framebuffer':'BLOCKED/not run','new_renderer_process_memory':None,'deployment_C':None,'full_b3b4':'BLOCKED','activation_qualified':False}
(out/'verification.json').write_text(json.dumps(summary,indent=2)+'\n',encoding='utf-8')
print(json.dumps(summary,indent=2))
