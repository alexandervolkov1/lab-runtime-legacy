import hashlib,json,pathlib,shutil,zipfile
root=pathlib.Path(__file__).resolve().parents[2]
work=root/'target/b3b4a-qualification'
final=work/'attempt-2'
verification=json.loads((final/'verification.json').read_bytes())
assert verification['gate_count']==34
destination=root/'docs/developer/isolated-native-renderer-child-b3b4a-evidence'
destination.mkdir(exist_ok=False)
for name in ['source-inputs.json','source-boundaries.json','gates.json','verification.json','test-inventory.txt','cpu-comparison.json','native-cargo-tree.txt']:
    shutil.copyfile(final/name,destination/name)
binaries=[]
for profile,folder in [('dev','debug'),('release','release')]:
    for role,path in [('runtime_virtual',f'target/{folder}/lab-runtime.exe'),('legacy_v1_workbench',f'target/{folder}/lab-workbench.exe'),('inert_native_capsule',f'target/{folder}/lab-native-child.exe'),('no_gpu_ipc_fixture',f'target/private-ipc/{profile}/private-ipc-fixture.exe'),('cpu_preview_probe',f'target/v2-renderer-allocation-probe/{profile}/v2-renderer-allocation-probe.exe'),('b2b2_compile_only',f'target/native-glow/{profile}/native-glow.exe')]:
        binaries.append({'profile':profile,'role':role,'path':path,'source_head':verification['source_head'],'sha256':hashlib.sha256((root/path).read_bytes()).hexdigest()})
(destination/'binary-identities.json').write_text(json.dumps(binaries,indent=2)+'\n',encoding='utf-8')
native=[]
for profile in ['dev','release']:
    summary=json.loads((final/(profile+'-v1-smoke.txt')).read_text().strip().splitlines()[-1])
    result=pathlib.Path(summary['result'])
    data=json.loads(result.read_bytes())
    for item in binaries:
        if item['profile']==profile and item['role'] in ('legacy_v1_workbench','runtime_virtual'):
            assert data['binaries_sha256'][pathlib.Path(item['path']).name]==item['sha256']
    shutil.copyfile(result,destination/('v1-'+profile+'.json'))
    image=root/data['window_capture']['path']
    assert hashlib.sha256(image.read_bytes()).hexdigest()==data['window_capture']['sha256']
    shutil.copyfile(image,destination/('v1-'+profile+'.png'))
    native.append((profile,result.parent))
archive=destination/'raw-evidence.zip'
with zipfile.ZipFile(archive,'w',zipfile.ZIP_DEFLATED,compresslevel=9) as saved:
    for attempt in ['attempt-1','attempt-2']:
        for path in sorted((work/attempt).glob('*')):
            if path.is_file():saved.write(path,f'{attempt}/{path.name}')
    for script in ['run.py','verify.py','archive.py']:
        saved.write(work/script,'audit/'+script)
    for profile in ['dev','release']:
        for name in ['native-child-capsule','v2-renderer-allocation-probe','private-ipc']:
            location=root/'target'/name/profile
            if name=='v2-renderer-allocation-probe': patterns=['*.txt','artifacts.json','main.rs']
            elif name=='native-child-capsule': patterns=['*.txt','*.rs','artifacts.json']
            else:patterns=['fixture.rs']
            for pattern in patterns:
                for path in sorted(location.glob(pattern)):
                    saved.write(path,f'{name}/{profile}/{path.name}')
        # The CompileOnly run does not overwrite historical smoke/fault output.
        # Archive ONLY its current compile inputs/artifacts, never old GPU logs.
        for file in ['main.rs','artifacts.json']:
            saved.write(root/'target/native-glow'/profile/file,f'native-glow-compile-only/{profile}/{file}')
    for profile,folder in native:
        for name in ['result.json','observer.json','smoke.json','runtime.toml','window.png']:
            saved.write(folder/name,f'v1/{profile}/{name}')
    saved.writestr('audit/scope.txt','B3B4A only. Both full suites pass on the final source. Original attempt-1 supervisor observer Busy failure is retained; attempt-2 uses bounded sampling without changing production behavior or weakening exit/termination assertions. Early development checks also found a fixture signal missing its original signal identity and a missing shared MAX_SHAPES alias; both were corrected before qualified source. Default native dependency features were rejected before the source commit because they would add registry records. Final registry records are exact. No renderer-child GL, framebuffer, process memory, deployment C, activation, or B3B5 qualification is claimed.\n')
with zipfile.ZipFile(archive) as saved:
    manifest=[{'path':name,'bytes':len(saved.read(name)),'sha256':hashlib.sha256(saved.read(name)).hexdigest()} for name in saved.namelist()]
    assert len({item['path'] for item in manifest})==len(manifest)
(destination/'raw-manifest.json').write_text(json.dumps(manifest,indent=2)+'\n',encoding='utf-8')
print(json.dumps({'destination':str(destination),'archive_bytes':archive.stat().st_size,'members':len(manifest),'archive_sha256':hashlib.sha256(archive.read_bytes()).hexdigest(),'binary_hashes':len(binaries)},indent=2))
