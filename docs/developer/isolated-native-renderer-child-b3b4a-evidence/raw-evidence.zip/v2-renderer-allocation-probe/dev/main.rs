#![deny(unsafe_code)]
#![allow(dead_code, unused_imports)]
#[path = "D:/rust_projects/lab-runtime/apps/lab-workbench/src/client/mod.rs"] mod client;
#[path = "D:/rust_projects/lab-runtime/apps/lab-workbench/src/dispatcher.rs"] mod dispatcher;
#[path = "D:/rust_projects/lab-runtime/apps/lab-workbench/src/external.rs"] mod external;
#[path = "D:/rust_projects/lab-runtime/apps/lab-workbench/src/model/mod.rs"] mod model;
#[path = "D:/rust_projects/lab-runtime/apps/lab-workbench/src/ownership.rs"] mod ownership;
#[path = "D:/rust_projects/lab-runtime/apps/lab-workbench/src/parent.rs"] mod parent;
#[path = "D:/rust_projects/lab-runtime/apps/lab-workbench/src/presentation/mod.rs"] mod presentation;
#[path = "D:/rust_projects/lab-runtime/apps/lab-workbench/src/recovery/mod.rs"] mod recovery;
#[path = "D:/rust_projects/lab-runtime/apps/lab-workbench/src/storage.rs"] mod storage;
#[path = "D:/rust_projects/lab-runtime/apps/lab-workbench/src/supervisor/mod.rs"] mod supervisor;
#[path = "D:/rust_projects/lab-runtime/apps/lab-workbench/src/private_ipc/mod.rs"] mod private_ipc;
#[path = "D:/rust_projects/lab-runtime/apps/lab-workbench/src/gui/rebuild.rs"] mod rebuild;
mod gui {
pub(crate) use crate::rebuild;
#[path = "D:/rust_projects/lab-runtime/apps/lab-workbench/src/gui/app.rs"] mod app;
#[path = "D:/rust_projects/lab-runtime/apps/lab-workbench/src/gui/controls.rs"] mod controls;
#[path = "D:/rust_projects/lab-runtime/apps/lab-workbench/src/gui/presentation.rs"] mod presentation;
#[path = "D:/rust_projects/lab-runtime/apps/lab-workbench/src/gui/readonly_v2/mod.rs"] pub(crate) mod readonly_v2;
#[path = "D:/rust_projects/lab-runtime/scripts/support/v1-renderer-probe.rs"] mod v1_probe;
pub(crate) use v1_probe::V1Scene;
}
use gui::readonly_v2;
#[path = "D:/rust_projects/lab-runtime/apps/lab-workbench/src/gui/readonly_v2/fixtures.rs"] mod fixtures;
#[path = "D:/rust_projects/lab-runtime/apps/lab-workbench/src/gui/readonly_v2/plot_fixtures.rs"] mod plot_fixtures;
#[path = "D:/rust_projects/lab-runtime/apps/lab-workbench/src/gui/readonly_v2/plot_geometry_fixtures.rs"] mod plot_geometry_fixtures;
#[path = "D:/rust_projects/lab-runtime/scripts/support/v2-renderer-allocation-probe.rs"] mod probe;
#[path = "D:/rust_projects/lab-runtime/scripts/support/glow-seam-check.rs"] mod glow_seam_check;
fn main() { probe::run(); }