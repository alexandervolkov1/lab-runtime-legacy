//! Compile-fail proof for the real native Device's non-Send boundary.
#![forbid(unsafe_code)]
#![allow(dead_code)]
#[path = "D:/rust_projects/lab-runtime/apps/lab-native-child/src/readonly_v2.rs"] mod readonly_v2;
#[path = "D:/rust_projects/lab-runtime/scripts/support/native-glow-device.rs"] mod device;
fn main() {}