import csv,hashlib,json,pathlib,re,subprocess
root=pathlib.Path(__file__).resolve().parents[2]
out=root/'target/b3b4b-qualification/final-attempt-3'
sha=lambda data:hashlib.sha256(data).hexdigest()
gates=json.loads((out/'gates.json').read_bytes())
assert len(gates)==42
assert sum(g['verdict']=='PASS' for g in gates)==42
assert sum(g['verdict']=='BLOCKED/profile' for g in gates)==0
source=json.loads((out/'source-inputs.json').read_bytes());head=source['source_head']
assert head==subprocess.check_output(['git','rev-parse','HEAD'],cwd=root,text=True).strip()
assert all(g['source_head']==head for g in gates)
for g in gates:assert sha((out/(g['name']+'.txt')).read_bytes())==g['log_sha256'],g['name']
for r in source['files']:
    assert sha((root/r['path']).read_bytes())==r['raw_sha256'],r['path']
    assert sha(subprocess.check_output(['git','show',f"HEAD:{r['path']}"],cwd=root))==r['git_sha256'],r['path']
profiles=[];inventories=[];cpu=[];identities=[];native=[]
for profile,directory in [('dev','debug'),('release','release')]:
    def text(name):return (out/(profile+'-'+name+'.txt')).read_text(encoding='utf-8-sig')
    def summary(name):
        rows=re.findall(r'test result: ok\. (\d+) passed; (\d+) failed; (\d+) ignored;',text(name));assert rows,name
        assert all(int(row[1])==0 for row in rows)
        selected=rows if name=='os-capsule' else rows[-1:]
        return {'passed':sum(int(r[0]) for r in selected),'ignored':sum(int(r[2]) for r in selected)}
    tests={name:summary(name) for name in ['full','handoff-provider','parent-supervisor','virtual','native-supervisor','native-ipc','os-capsule']}
    assert tests['full']=={'passed':529,'ignored':49}
    assert tests['handoff-provider']['passed']==23 and tests['virtual']['passed']==13
    assert tests['native-supervisor']['passed']==7 and tests['native-ipc']['passed']==22
    assert text('cpu-preview').count('Ownership compile-fail PASS:')==10
    assert 'non-Send E0277 and protected-policy E0453 rejection PASS' in text('native-capsule')
    assert 'B2B2 standalone compile and Clippy PASS; no GPU execution' in text('standalone-compile')
    assert 'HANDOFF actual_admitted_peak=1 calls=2 constructed=2 dropped=2 slots=4' in text('handoff-provider')
    assert 'NO_GPU persistent_parsed_documents=0 actual_admitted_peak=1 encoded_slots=4' in text('handoff-provider')
    assert 'SELECTED_PROVIDER accounted_view_bytes=9390 fixed_bytes=9336 target_string_ceiling=131072 encoded_copy_bytes=0' in text('handoff-provider')
    inventory=[s for s in text('inventory').splitlines() if s.endswith(': test')];assert len(inventory)==578;inventories.append(inventory)
    for suite,count in [('geometry',119),('memory',125),('frames',12),('host-no-upload',4),('retirement',9)]:
        path=root/f'target/v2-renderer-allocation-probe/{profile}/{suite}.txt'
        lines=path.read_text(encoding='utf-8-sig').splitlines();start=next(i for i,line in enumerate(lines) if line.startswith('scenario,'))
        rows=[r for r in csv.DictReader(lines[start:]) if r.get('status') is not None or r.get('result') is not None]
        assert len(rows)==count,(profile,suite,len(rows));maximum=max(int(r['accounted']) for r in rows);assert maximum<=8388608
        cpu.append({'profile':profile,'suite':suite,'rows':len(rows),'max_accounted':maximum,'allowance':8388608,'raw_sha256':sha(path.read_bytes())})
    smoke=json.loads(text('v1-smoke').strip().splitlines()[-1]);assert smoke['status']=='pass'
    v1path=pathlib.Path(smoke['result']);v1=json.loads(v1path.read_bytes())
    assert (v1['connections'],v1['mutation_submissions'],v1['status_submissions'],v1['repeat_mutation_submissions'])==(2,1,0,0)
    assert v1['binary_source_head']==head
    profiles.append({'profile':profile,'tests':tests,'borrowing':10,'v1_result':str(v1path),'v1_connections':2,'v1_explicit_mutations':1,'v1_status_repeat':0})
    assert summary('isolated-first-frame')=={'passed':5,'ignored':0}
    assert 'GPU RENDER SMOKE PASS; HEALTHY GPU LIFECYCLE PASS' in text('standalone-native')
    assert 'FAULT timeout-proof PASS' in text('standalone-faults')
    assert text('standalone-faults').count('containment witnessed; TERMINAL GPU LIFECYCLE BLOCKED')==19
    assert 'keys=1, context=true, frame=true' in text('standalone-pending')
    match=re.search(r'FIRST_ISOLATED_REAL_GL_FRAME PASS evidence=(.+?) peak_process_commit=',text('isolated-first-frame'));assert match
    path=pathlib.Path(match.group(1));result=json.loads((path/'parent-result.json').read_bytes())
    assert result['first_isolated_real_gl_frame']=='PASS' and result['final_phase']=='ExitedHealthy'
    assert result['own_objects']==0 and result['original_ipc_retired'] and result['runtime_extra_query_mutation_status_retry']==0
    assert result['deployment_C'] is None and result['test_only_job_commit_cap']==1073741824
    own=json.loads((path/'own-retired.json').read_bytes());assert own['own_objects']==0 and 'Some(' not in own['ledger']
    assert own['final_wgl_destruction']=='LIMITED/no new receipt'
    admitted=[json.loads(p.read_bytes()) for p in path.glob('admitted-*.json')]
    assert len(admitted)==2 and {d['epoch_revision'] for d in admitted}=={2,3} and all(d['max_live_parsed']==1 for d in admitted)
    frames=[]
    for metadata in sorted(path.glob('frame-*.json')):
        frame=json.loads(metadata.read_bytes());rgba=metadata.with_suffix('.rgba');assert rgba.stat().st_size==4915200
        assert frame['geometry_failures']==0 and frame['width']==1280 and frame['height']==960 and frame['scale']==1
        assert frame['matched_samples']==len(frame['curve_samples']) and frame['encoded_slots']==4
        frames.append({'metadata':str(metadata),'metadata_sha256':sha(metadata.read_bytes()),'rgba_sha256':sha(rgba.read_bytes()),'points':frame['plot_points'],'samples':frame['matched_samples'],'epoch_revision':frame['epoch_revision'],'current':frame['current']})
    assert any(f['points']==64 and f['samples']>0 for f in frames)
    assert any(f['points']==65 and f['epoch_revision']==3 for f in frames)
    assert any(json.loads(pathlib.Path(f['metadata']).read_bytes())['cyan_pixels']==0 for f in frames if f['points']==0)
    milestones=json.loads((path/'memory-milestones.json').read_bytes());assert len(milestones['samples'])==8
    faults=[]
    for mode,fault_directory in re.findall(r'ISOLATED_FAULT PASS mode=(\S+) evidence=(.+?) extra_runtime_submissions=0',text('isolated-first-frame')):
        directory_path=pathlib.Path(fault_directory);fault=json.loads((directory_path/'parent-fault-result.json').read_bytes())
        assert fault['extra_runtime_query_mutation_status_retry']==0 and fault['final_incarnation']==2 and fault['final_phase']=='ExitedHealthy'
        assert fault['explicit_restart_latest_snapshots'] and fault['original_process_exit_and_ipc_retirement'] and fault['deployment_C'] is None
        restart=directory_path.with_name(directory_path.name[:-1]+'2');assert restart.is_dir()
        restart_own=json.loads((restart/'own-retired.json').read_bytes());assert restart_own['own_objects']==0
        if mode=='pending-gpu-document-handoff-stop':
            assert fault['details']['bounded_complete_assembly_survived_transfer_deadline'] and fault['details']['pending']['max_live_parsed']==1
            assert not (directory_path/'admitted-2.json').exists() and not (directory_path/'own-retired.json').exists()
        if mode=='native-render-owner-stall': assert fault['details']['reason'] in ('Some(HeartbeatDeadline)','Some(OwnerProgressDeadline)')
        faults.append({'mode':mode,'directory':str(directory_path),'restart_directory':str(restart),'result':fault})
    assert len(faults)==4
    native.append({'profile':profile,'directory':str(path),'result':result,'admitted':admitted,'frames':frames,'memory_milestones':milestones,'faults':faults})
    for scenario in ['standalone-native','standalone-pending','standalone-faults']:
        receipt=re.search(r'^STANDALONE_IDENTITY=(.+)$',text(scenario),re.M);assert receipt
        ident=json.loads(pathlib.Path(receipt.group(1).strip()).read_text(encoding='utf-8-sig'));assert ident['source_head']==head
        identities.append({'profile':profile,'role':scenario,'receipt':receipt.group(1).strip(),**ident})
    identity=json.loads((root/f'target/b3b4b-qualification/native-{profile}/identity.json').read_text(encoding='utf-8-sig'))
    assert identity['source_head']==head and identity['sha256'].lower()==sha(pathlib.Path(identity['binary']).read_bytes())
    candidates={'native-child':pathlib.Path(identity['binary']),'workbench':root/f'target/{directory}/lab-workbench.exe','workbench-tests':root/re.search(r'Running unittests[^\n]+\((target[^\r\n]+\.exe)\)',text('full')).group(1),'runtime':root/f'target/{directory}/lab-runtime.exe',
        'cpu-preview':root/f'target/v2-renderer-allocation-probe/{profile}/v2-renderer-allocation-probe.exe',
        'standalone-compile-only':root/f'target/native-glow/{profile}/native-glow.exe',
        'private-ipc-fixture':pathlib.Path(re.search(r'^FIXTURE=(.+)$',text('native-ipc'),re.M).group(1).strip()),
        'supervisor-fixture':pathlib.Path(re.search(r'^FIXTURE=(.+)$',text('native-supervisor'),re.M).group(1).strip())}
    for role,path in candidates.items():
        assert path.is_file(),path
        identities.append({'profile':profile,'role':role,'path':str(path),'source_head':head,'bytes':path.stat().st_size,'sha256':sha(path.read_bytes())})
assert inventories[0]==inventories[1]
(out/'test-inventory.txt').write_text('\n'.join(inventories[0])+'\n',encoding='utf-8')
for name,data in [('cpu-summary.json',cpu),('native-results.json',native),('binary-identities.json',identities)]:
    (out/name).write_text(json.dumps(data,indent=2)+'\n',encoding='utf-8')
deps=(root/'target/debug/lab-native-child.d').read_text()
paths=sorted({str(pathlib.Path(p).resolve().relative_to(root)).replace('\\','/') for p in re.findall(r'[A-Za-z]:\\[^ \r\n]+\.rs',deps)})
assert any(p.endswith('readonly_v2/mod.rs') for p in paths)
for path in paths:
    assert '/model/' not in path and '/client/' not in path and not path.endswith(('/dispatcher.rs','/parent.rs','/external.rs','/source_v1.rs','/conversion.rs','/export.rs')),path
(out/'child-compiler-inputs.json').write_text(json.dumps([{'path':p,'sha256':sha((root/p).read_bytes())} for p in paths],indent=2)+'\n',encoding='utf-8')
summary={'source_head':head,'gate_count':42,'pass':42,'blocked':0,'profiles':profiles,'source_inputs':len(source['files']),'child_compiler_inputs':len(paths),
    'max_live_admitted':1,'no_gpu_persistent_admitted':0,'encoded_slots':4,'selected_view_fixture_bytes':9390,
    'first_isolated_frame':'PASS/native fixed profile','full_b3b4':'BLOCKED','terminal_gpu_general':'BLOCKED','whole_host_rust_budget':'BLOCKED','cycles_100_plus':'UNQUALIFIED','historical_hello_only':'UNQUALIFIED','m17_4_overlap':'BLOCKED','deployment_C':None,'activation_qualified':False}
(out/'verification.json').write_text(json.dumps(summary,indent=2)+'\n',encoding='utf-8')
print(json.dumps(summary,indent=2))
