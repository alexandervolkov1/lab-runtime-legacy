#![forbid(unsafe_code)]
#![allow(dead_code)]
#[path="D:/rust_projects/lab-runtime/apps/lab-workbench/src/private_ipc/renderer_progress.rs"] mod progress;
fn main(){println!("{{\"renderer_progress_struct\":{},\"optional_metadata_per_owner\":{},\"encoded_diagnostic\":{}}}",std::mem::size_of::<progress::RendererProgress>(),std::mem::size_of::<Option<progress::RendererProgress>>(),progress::RendererProgress::default().encode().len());}
