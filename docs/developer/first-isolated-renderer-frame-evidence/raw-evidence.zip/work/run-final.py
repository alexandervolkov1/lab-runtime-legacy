import hashlib,json,pathlib,subprocess,sys,time

root=pathlib.Path(__file__).resolve().parents[2]
out=pathlib.Path(__file__).resolve().parent/'final-attempt-3'
out.mkdir(exist_ok=False)
head=subprocess.check_output(['git','rev-parse','HEAD'],cwd=root).decode().strip()
names=subprocess.check_output(['git','ls-files'],cwd=root).decode().splitlines()
names=sorted(p for p in names if (p in ('Cargo.toml','Cargo.lock') or p.startswith(('apps/','crates/','scripts/','examples/','test-data/'))) and pathlib.Path(p).suffix in ('.rs','.toml','.lock','.ps1','.py','.json','.edn'))
inventory=[]
for path in names:
    blob=subprocess.check_output(['git','show',f'{head}:{path}'],cwd=root)
    raw=(root/path).read_bytes()
    assert raw.replace(b'\r\n',b'\n')==blob.replace(b'\r\n',b'\n'),path
    inventory.append({'path':path,'git_sha256':hashlib.sha256(blob).hexdigest(),'raw_sha256':hashlib.sha256(raw).hexdigest()})
(out/'source-inputs.json').write_text(json.dumps({'source_head':head,'files':inventory},indent=2)+'\n',encoding='utf-8')
gates=[]
def add(name,command): gates.append((name,command))
add('environment',['pwsh','-NoProfile','-Command','rustc -vV; cargo -V; python --version; Get-CimInstance Win32_OperatingSystem | Select-Object Caption,Version,OSArchitecture; git rev-parse HEAD; git status --short'])
add('observer-reset',[sys.executable,'-B','scripts/support/v1-parent-pump-smoke.py','--self-test-reset'])
for profile in ('dev','release'):
    cargo=['cargo','test','-p','lab-workbench','--locked','--profile',profile,'--']
    add(profile+'-build',['cargo','build','-p','lab-runtime','-p','lab-workbench','--locked','--profile',profile])
    add(profile+'-inventory',cargo+['--list'])
    add(profile+'-handoff-provider',cargo+['gui::readonly_v2::tests::individual_stale','private_ipc::handoff_tests','private_ipc::provider_tests','private_ipc::selected_preview_tests','private_ipc::renderer_progress','private_ipc::tests','--test-threads=1','--nocapture'])
    add(profile+'-clippy',['cargo','clippy','-p','lab-workbench','-p','lab-windows-job','-p','lab-native-child','--locked','--all-targets','--all-features','--profile',profile,'--','-D','warnings'])
    add(profile+'-full',cargo+['--test-threads=1','--nocapture'])
    add(profile+'-parent-supervisor',cargo+['parent::','supervisor::tests','architecture','ordinary_gui','gui::app::tests','--test-threads=1','--nocapture'])
    add(profile+'-virtual',cargo+['runtime_acceptance::','--ignored','--skip','m17_4','--test-threads=1','--nocapture'])
    for name,script in [('native-supervisor','test-windows-supervisor.ps1'),('native-ipc','test-private-ipc.ps1'),('native-capsule','test-native-child-capsule.ps1'),('cpu-preview','test-v2-renderer-allocation.ps1')]:
        add(profile+'-'+name,['pwsh','-NoProfile','-File','scripts/'+script,'-BuildProfile',profile])
    add(profile+'-isolated-first-frame',['pwsh','-NoProfile','-File','scripts/test-isolated-renderer.ps1','-BuildProfile',profile])
    add(profile+'-standalone-native',['pwsh','-NoProfile','-File','scripts/test-native-glow.ps1','-BuildProfile',profile])
    add(profile+'-standalone-pending',['pwsh','-NoProfile','-File','scripts/test-native-glow.ps1','-BuildProfile',profile,'-Pending'])
    add(profile+'-standalone-faults',['pwsh','-NoProfile','-File','scripts/test-native-glow.ps1','-BuildProfile',profile,'-Faults'])
    add(profile+'-standalone-compile',['pwsh','-NoProfile','-File','scripts/test-native-glow.ps1','-BuildProfile',profile,'-CompileOnly'])
    add(profile+'-os-capsule',['cargo','test','-p','lab-windows-job','--locked','--all-features','--profile',profile,'--','--nocapture'])

    add(profile+'-v1-smoke',[sys.executable,'-B','scripts/support/v1-parent-pump-smoke.py','--profile',profile])
add('document-allocation',['pwsh','-NoProfile','-File','scripts/test-v2-allocation.ps1'])
add('fmt',['cargo','fmt','--all','--','--check'])
add('powershell-ast',['pwsh','-NoProfile','-Command',"$items=@('scripts/test-native-child-capsule.ps1','scripts/test-native-glow.ps1','scripts/test-v2-renderer-allocation.ps1','scripts/test-private-ipc.ps1','scripts/test-v2-allocation.ps1','scripts/test-isolated-renderer.ps1'); foreach ($item in $items) { $tokens=$null; $errors=$null; [System.Management.Automation.Language.Parser]::ParseFile((Resolve-Path $item),[ref]$tokens,[ref]$errors) | Out-Null; if ($errors.Count) { throw ($errors | Out-String) } }; Write-Output 'PowerShell AST PASS'"])
add('diff-check',['git','diff','--check'])
results=[]
for name,command in gates:
    for item in inventory: assert hashlib.sha256((root/item['path']).read_bytes()).hexdigest()==item['raw_sha256'],item['path']
    print('START '+name,flush=True)
    (out/'running.json').write_text(json.dumps({'name':name,'command':command,'source_head':head},indent=2),encoding='utf-8')
    start=time.monotonic()
    with (out/(name+'.txt')).open('wb') as log:
        result=subprocess.run(command,cwd=root,stdout=log,stderr=subprocess.STDOUT,check=False)
    record={'name':name,'command':command,'source_head':head,'exit_code':result.returncode,'elapsed_seconds':round(time.monotonic()-start,3),'log_sha256':hashlib.sha256((out/(name+'.txt')).read_bytes()).hexdigest()}
    profile_blocked = False
    record['verdict']='BLOCKED/profile' if profile_blocked else ('PASS' if result.returncode==0 else 'FAIL')
    results.append(record)
    (out/'gates.json').write_text(json.dumps(results,indent=2)+'\n',encoding='utf-8')
    print('DONE '+name+' exit='+str(result.returncode)+' seconds='+str(record['elapsed_seconds']),flush=True)
    if result.returncode and not profile_blocked:
        print((out/(name+'.txt')).read_text(encoding='utf-8',errors='replace')[-7000:],flush=True)
        sys.exit(result.returncode)
print('FINAL QUALIFICATION source='+head+' records='+str(len(results))+' blocked='+str(sum(r['verdict'].startswith('BLOCKED') for r in results)),flush=True)
