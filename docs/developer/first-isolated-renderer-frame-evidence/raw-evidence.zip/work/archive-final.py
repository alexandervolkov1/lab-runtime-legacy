import hashlib,json,pathlib,shutil,zipfile
root=pathlib.Path(__file__).resolve().parents[2];work=root/'target/b3b4b-qualification';final=work/'final-attempt-3'
verification=json.loads((final/'verification.json').read_bytes());assert verification['pass']==42 and verification['blocked']==0
destination=root/'docs/developer/first-isolated-renderer-frame-evidence';destination.mkdir(exist_ok=False)
for name in ['source-inputs.json','gates.json','verification.json','test-inventory.txt','cpu-summary.json','native-results.json','binary-identities.json','child-compiler-inputs.json']:
    shutil.copyfile(final/name,destination/name)
shutil.copyfile(work/'source-boundaries.json',destination/'source-boundaries.json')
shutil.copyfile(work/'merge-b3b4a.json',destination/'merge-b3b4a.json')
shutil.copyfile(work/'final-native-cargo-tree.txt',destination/'native-cargo-tree.txt')
native=[]
for profile in ['dev','release']:
    smoke=json.loads((final/(profile+'-v1-smoke.txt')).read_text(encoding='utf-8-sig').strip().splitlines()[-1])
    result=pathlib.Path(smoke['result']);data=json.loads(result.read_bytes())
    shutil.copyfile(result,destination/('v1-'+profile+'.json'))
    capture=root/data['window_capture']['path'];assert hashlib.sha256(capture.read_bytes()).hexdigest()==data['window_capture']['sha256']
    shutil.copyfile(capture,destination/('v1-'+profile+'.png'));native.append((profile,result.parent))
experiments={
 'scope':'B3B4B FIRST ISOLATED REAL GL FRAME PASS in dev/release fixed existing B2B2 profile. Full B3B4, terminal general lifecycle, whole-host Rust and100cycles remain BLOCKED/unqualified. Activation false; C unselected.',
 'native_experiments':[
  {'attempt':'first-native-dev-attempt-1','source_head':'d3f8f8a9546d0ab049e99bfda344d5ca736cefdf','binary_sha256':'6D49FA76E82CCC5C50B032D9865B9F22AA727C724ACDD698015E497EB7BE8113','result':'startup exit91; pre-handshake error text not captured; test observer panic poisoned its mutex'},
  {'attempt':'first-native-dev-attempt-2','source_head':'2b1457b','binary_sha256':None,'provenance_limit':'Intermediate identity file was overwritten before archival; exact intermediate binary hash is not recovered or fabricated. Source remains in Git.','result':'Device scale-one guard; cwd fixed; status observer still poisoned on expected startup failure'},
  {'attempt':'first-native-dev-attempt-3','source_head':'1aa38c096cda40e1f15e96925ccc16a43f1fb632','identity_file':'first-native-dev-attempt-3-identity.json','result':'scale1.25 profile captured; original exit/IPC retirement and parent join observed without poisoned mutex'},
 ],
 'earlier_checks':[
  'Stage A shared values: typed-read tests pass dev/release.',
  'Early B compile attempts found Windows Python cp1252 output in read.rs (fixed before source commit), Default inference requiring explicit cache types, and stale test assumptions about a reference selector. Raw compiler/test logs retained.',
  'An exploratory GUI suite was cancelled after a simultaneous relink hit the running test.exe lock; final tests run serially.',
  'Capsule checks built and rejected expected E0277/E0453, but PowerShell left LASTEXITCODE at the last expected negative rejection; script now resets it only after both controls pass.',
  'Final-attempt-1 on41233f completed full dev526/45 and other gates; its CPU run was cancelled for the discovered individual-entry freshness bug. Completed results are historical to that source.',
  'Two real Preview regressions failed before the freshness fix. Before-fix source is41233f plus the two new tests (their exact test blob is atf31f2d1); fixed sourcef31f2d1 passes both and all final suites.',
  'The old scale1.25 assessment was an agent oversight: original B2B2 already used process-local with_dpi_aware(false). Commit973a1bd reuses exactly that accepted profile without changing Device guards or OS DPI. Standalone f31 smoke already passed dev/release; final child frames and fault cases now pass too.',
  'Attempt4 at973a1bd produced real frames but title-only document replacement did not change visible Plot pixels; bounded assertions and actual axis replacement followed atdca775f. The 39MB assertion dump is preserved compressed.',
  'Attempt5 atdca775f proved empty own-object ledger but exact Close challenge was consumed by interimStatus: parent correctly ExitedContained at exit0. Commitc1bf482 preserves the Close challenge until real own-object release; attempt6 passes.',
  'Early native attempts2,4,5,6 and old standalone controls before per-run identity archival have source/raw evidence but some intermediate binary hashes were overwritten and are unavailable. No hash is fabricated. Final runs archive binary identities before execution.',
  'Fault dev attempt1 at823c1a3 passed5 tests but owner stall happened before Ready (StartupDeadline). Final source1d297ad waits for actual frame progress publication before the injected stall and observes HeartbeatDeadline. Both attempts are retained.' ,
 ]}
(destination/'experiments.json').write_text(json.dumps(experiments,indent=2)+'\n',encoding='utf-8')
files={}
def add(path,arc):
    if path.is_file():assert arc not in files,arc;files[arc]=path
for path in sorted(work.rglob('*')):
    if path.is_file() and path.suffix in ('.txt','.json','.py','.diff','.rs') and path.name!='continuation.json':add(path,'work/'+path.relative_to(work).as_posix())
for profile in ['dev','release']:
    for folder,patterns in [('native-child-capsule',['*.rs','*.txt','artifacts.json']),('v2-renderer-allocation-probe',['*.txt','artifacts.json','main.rs']),('private-ipc',['fixture.rs'])]:
        directory=root/'target'/folder/profile
        for pattern in patterns:
            for path in directory.glob(pattern):
                arc=f'{folder}/{profile}/{path.name}'
                if arc not in files:add(path,arc)
    # Select only current smoke/compile controls. Never relabel historical GPU faults.
    for name in ['main.rs','artifacts.json'] + [p.name for p in (root/f'target/native-glow/{profile}').glob('*.txt')] + [p.name for p in (root/f'target/native-glow/{profile}').glob('identity-*.json')]:
        add(root/f'target/native-glow/{profile}'/name,f'native-glow/{profile}/{name}')
for folder in ['debug','release']:
    directory=root/f'target/{folder}/target/isolated-native-renderer'
    if directory.exists():
        for path in directory.rglob('*'):
            if path.is_file() and path.suffix in ('.json','.rgba'):add(path,f'actual-child/{folder}/'+path.relative_to(directory).as_posix())
for profile,directory in native:
    for name in ['result.json','observer.json','smoke.json','runtime.toml','window.png']:add(directory/name,f'v1/{profile}/{name}')
archive=destination/'raw-evidence.zip'
with zipfile.ZipFile(archive,'w',zipfile.ZIP_DEFLATED,compresslevel=9) as saved:
    for name,path in sorted(files.items()):saved.write(path,name)
    saved.writestr('audit/scope.txt',experiments['scope']+'\nOriginal child GL RGBA buffers and their metadata are archived. GL origin is bottom-left. v1 GDI images are legacy regression evidence only. Previous evidence directories/manifests are preserved.\n')
with zipfile.ZipFile(archive) as saved:
    manifest=[{'path':name,'bytes':len(saved.read(name)),'sha256':hashlib.sha256(saved.read(name)).hexdigest()} for name in saved.namelist()]
    assert len(manifest)==len(set(item['path'] for item in manifest))
(destination/'raw-manifest.json').write_text(json.dumps(manifest,indent=2)+'\n',encoding='utf-8')
print(json.dumps({'destination':str(destination),'archive_bytes':archive.stat().st_size,'members':len(manifest),'archive_sha256':hashlib.sha256(archive.read_bytes()).hexdigest()},indent=2))
