import hashlib,json,pathlib,re,subprocess,tomllib
root=pathlib.Path(__file__).resolve().parents[2]
out=root/'target/b3b4b-qualification'
baseline='25ca736074e304d83c1c74b03d5dca5d16697e41'
head=subprocess.check_output(['git','rev-parse','HEAD'],cwd=root,text=True).strip()
def blob(rev,path):return subprocess.check_output(['git','show',f'{rev}:{path}'],cwd=root)
def text(rev,path):return blob(rev,path).decode().replace('\r\n','\n')
def digest(data):return hashlib.sha256(data).hexdigest()
protected=[
'scripts/support/native-glow-device.rs',
'apps/lab-workbench/src/gui/readonly_v2/host_session.rs',
'apps/lab-workbench/src/gui/readonly_v2/texture_owner.rs',
'apps/lab-workbench/src/gui/readonly_v2/completion.rs',
'apps/lab-workbench/src/gui/readonly_v2/deletion.rs',
'apps/lab-workbench/src/gui/readonly_v2/native_types.rs',
'apps/lab-workbench/src/gui/readonly_v2/finite_trace.rs',
'apps/lab-workbench/src/gui/readonly_v2/plot_bounds.rs',
'apps/lab-workbench/src/private_ipc/protocol.rs',
'apps/lab-workbench/src/private_ipc/replica.rs',
'apps/lab-workbench/src/private_ipc/document_owner.rs',
'apps/lab-workbench/src/private_ipc/fixture.rs',
'apps/lab-workbench/src/private_ipc/parent_bridge.rs',
'apps/lab-workbench/src/private_ipc/transport.rs',
'apps/lab-workbench/src/supervisor/mod.rs',
'apps/lab-workbench/src/supervisor/windows.rs',
'apps/lab-workbench/src/dispatcher.rs',
'apps/lab-workbench/src/gui/app.rs',
'apps/lab-workbench/src/gui/presentation.rs',
'apps/lab-workbench/src/gui/controls.rs',
'apps/lab-workbench/src/presentation/reference.rs',
'apps/lab-workbench/src/recovery/mod.rs',
'Cargo.toml',
'apps/lab-workbench/Cargo.toml',
]
protected += [f'apps/lab-workbench/src/presentation/v2/{name}.rs' for name in ['admission','allocation','bounded','canonical','dto','encoding','graph','structure','validation','visual_budget','wire']]
framepath='apps/lab-workbench/src/gui/readonly_v2/frame.rs'
assert text(baseline,framepath).split('#[cfg(test)]')[0]==text(head,framepath).split('#[cfg(test)]')[0]
oldadmission=text(baseline,'apps/lab-workbench/src/presentation/v2/mod.rs')
newadmission=text(head,'apps/lab-workbench/src/presentation/v2/consumer.rs')
start='/// A closed-shape document'
assert oldadmission[oldadmission.index(start):oldadmission.index('#[cfg(test)]\npub(crate) mod admission_fixtures;')].strip()==newadmission[newadmission.index(start):].strip()
records=[]
for path in protected:
    old=blob(baseline,path);new=blob(head,path);assert old==new,path
    records.append({'path':path,'sha256':digest(new),'baseline_exact':True})
unchanged_trees=['apps/lab-runtime','crates/lab-core','crates/lab-windows-job','clients','apps/lab-workbench/src/client']
for path in unchanged_trees:
    assert not subprocess.check_output(['git','diff','--name-only',baseline,head,'--',path],cwd=root),path
old=tomllib.loads(text(baseline,'Cargo.lock'))['package'];new=tomllib.loads(text(head,'Cargo.lock'))['package']
external=lambda packages:[p for p in packages if not p['name'].startswith('lab-')]
assert external(old)==external(new)
oldsmoke=text(baseline,'scripts/support/native-glow-smoke.rs')
before=oldsmoke[oldsmoke.index('impl FrameBackend for Backend {'):oldsmoke.index('struct Root {')].strip()
newbackend=text(head,'scripts/support/native-glow-backend.rs');after=newbackend[newbackend.index('impl FrameBackend for Backend {'):].strip()
tokens=lambda s:re.sub(r'\s+','',s)
assert tokens(before)==tokens(after),'safe Backend forwarding changed'
shared=text(head,'apps/lab-workbench/src/readonly_values.rs')
oldproj=text(baseline,'apps/lab-workbench/src/model/projections.rs')
oldread=text(baseline,'apps/lab-workbench/src/model/read_binding.rs')
blocks=[oldproj[oldproj.index('/// Freshness of a rebuildable'):oldproj.index('/// Last observed plain')],
        oldproj[oldproj.index('/// One display-only live point'):oldproj.index('/// Bounded display window')],
        oldread[oldread.index('/// A finite semantic selector'):oldread.index('/// Decoded scalar with')],
        oldread[oldread.index('/// Sample quality is independent'):oldread.index('#[derive(Clone, Debug, PartialEq, Eq)]\npub(crate) struct ReadUnit')]]
for block in blocks:assert tokens(block) in tokens(shared),'moved value definition changed'
limits=text(head,'apps/lab-workbench/src/readonly_limits.rs')
oldlimits=text(baseline,'apps/lab-workbench/src/external.rs')+text(baseline,'apps/lab-workbench/src/presentation/document.rs')
constants=re.findall(r'pub\(crate\) const (\w+): usize = ([^;]+);',limits)
assert len(constants)==7
for name,value in constants:assert f'pub(crate) const {name}: usize = {value};' in oldlimits,(name,value)
changed=subprocess.check_output(['git','diff','--name-only','754857771b6fb55491599817010871736f748027',head],cwd=root,text=True).splitlines()
result={'source_head':head,'reviewed_baseline':baseline,'protected_files':records,'unchanged_trees':unchanged_trees,
 'internal_backend_change':'optional bounded renderer Diagnostic observation and cfg(test) original Job sampling only; protocol, slots, authority, process/IPC retirement unchanged','external_lock_records_unchanged':len(external(old)),'safe_native_backend_impl_token_exact':digest(tokens(before).encode()),'production_frame_byte_exact':True,'pure_admission_body_byte_exact':True,
 'canonical_shared_value_blocks_token_exact':[digest(tokens(b).encode()) for b in blocks],
 'numeric_limits_unchanged':dict(constants),'changed_code_paths':changed,'activation_qualified':False,
 'first_isolated_frame':'PASS/native fixed profile','deployment_C':None}
(out/'source-boundaries.json').write_text(json.dumps(result,indent=2)+'\n',encoding='utf-8')
print(json.dumps({'source_head':head,'protected_files':len(records),'unchanged_trees':len(unchanged_trees),'external_lock_records':len(external(old)),'changed_paths':len(changed),'numeric_limits':len(constants)},indent=2))
