import hashlib,json,pathlib,struct,zlib
root=pathlib.Path(__file__).resolve().parents[2]
work=root/'target/b3b4b-qualification/final-attempt-3'
destination=root/'docs/developer/first-isolated-renderer-frame-evidence'
records=[]
for native in json.loads((work/'native-results.json').read_bytes()):
    frames=[(pathlib.Path(f['metadata']),json.loads(pathlib.Path(f['metadata']).read_bytes())) for f in native['frames']]
    choices={
      'no-data':lambda f:f['plot'] and f['plot_points']==0 and f['observation_snapshot']!=0,
      'scalar':lambda f:not f['plot'] and f['current'] and 'Runtime unit: V' in f['labels'] and 'Fresh\n' in f['labels'],
      'selected-plot':lambda f:f['plot'] and f['current'] and f['plot_points']==64,
      'live-plot':lambda f:f['plot'] and f['current'] and f['plot_points']==65 and f['epoch_revision']==2,
      'document-replacement':lambda f:f['plot'] and f['current'] and f['plot_points']==65 and f['epoch_revision']==3,
    }
    for name,predicate in choices.items():
        metadata,frame=next((p,f) for p,f in frames if predicate(f))
        rgba=metadata.with_suffix('.rgba').read_bytes();w,h=frame['width'],frame['height'];assert len(rgba)==w*h*4
        rows=b''.join(b'\0'+rgba[y*w*4:(y+1)*w*4] for y in reversed(range(h)))
        def chunk(tag,data):return struct.pack('>I',len(data))+tag+data+struct.pack('>I',zlib.crc32(tag+data))
        png=b'\x89PNG\r\n\x1a\n'+chunk(b'IHDR',struct.pack('>IIBBBBB',w,h,8,6,0,0,0))+chunk(b'IDAT',zlib.compress(rows,9))+chunk(b'IEND',b'')
        output=destination/(native['profile']+'-'+name+'.png');output.write_bytes(png)
        records.append({'profile':native['profile'],'scenario':name,'metadata':str(metadata),'raw_rgba_archive_member':'actual-child/'+('debug' if native['profile']=='dev' else 'release')+'/'+metadata.parent.name+'/'+metadata.with_suffix('.rgba').name,'rgba_sha256':hashlib.sha256(rgba).hexdigest(),'png':output.name,'png_sha256':hashlib.sha256(png).hexdigest(),'transform':'lossless GL bottom-left to PNG top-left row reversal only','points':frame['plot_points'],'epoch_revision':frame['epoch_revision']})
(destination/'frame-pictures.json').write_text(json.dumps(records,indent=2)+'\n',encoding='utf-8')
print(json.dumps({'actual_gl_pngs':len(records)},indent=2))
