#![forbid(unsafe_code)]
#![allow(dead_code, unused_imports)]
#[path = "D:/rust_projects/lab-runtime/apps/lab-workbench/src/client/mod.rs"] mod client;
#[path = "D:/rust_projects/lab-runtime/apps/lab-workbench/src/dispatcher.rs"] mod dispatcher;
#[path = "D:/rust_projects/lab-runtime/apps/lab-workbench/src/external.rs"] mod external;
#[path = "D:/rust_projects/lab-runtime/apps/lab-workbench/src/gui/mod.rs"] mod gui;
#[path = "D:/rust_projects/lab-runtime/apps/lab-workbench/src/readonly_limits.rs"] mod readonly_limits;
#[path = "D:/rust_projects/lab-runtime/apps/lab-workbench/src/readonly_values.rs"] mod readonly_values;
#[path = "D:/rust_projects/lab-runtime/apps/lab-workbench/src/readonly_cache.rs"] mod readonly_cache;
#[path = "D:/rust_projects/lab-runtime/apps/lab-workbench/src/model/mod.rs"] mod model;
#[path = "D:/rust_projects/lab-runtime/apps/lab-workbench/src/ownership.rs"] mod ownership;
#[path = "D:/rust_projects/lab-runtime/apps/lab-workbench/src/parent.rs"] mod parent;
#[path = "D:/rust_projects/lab-runtime/apps/lab-workbench/src/presentation/mod.rs"] mod presentation;
#[path = "D:/rust_projects/lab-runtime/apps/lab-workbench/src/private_ipc/mod.rs"] mod private_ipc;
#[path = "D:/rust_projects/lab-runtime/apps/lab-workbench/src/recovery/mod.rs"] mod recovery;
#[path = "D:/rust_projects/lab-runtime/apps/lab-workbench/src/storage.rs"] mod storage;
#[path = "D:/rust_projects/lab-runtime/apps/lab-workbench/src/supervisor/mod.rs"] mod supervisor;
#[path = "D:/rust_projects/lab-runtime/apps/lab-workbench/src/gui/rebuild.rs"] mod rebuild;
fn main() { if let Err(error) = private_ipc::fixture::run() { eprintln!("{error:?}"); std::process::exit(91); } }