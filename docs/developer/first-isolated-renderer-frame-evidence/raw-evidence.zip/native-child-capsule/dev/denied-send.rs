//! Compile-fail proof for the real native Device's non-Send boundary.
#![deny(unsafe_code)]
#![allow(dead_code, unused_imports)]
#[path = "D:/rust_projects/lab-runtime/apps/lab-native-child/src/consumer.rs"] mod consumer;
pub(crate) use consumer::{presentation, private_ipc, readonly_limits, readonly_v2, readonly_values};
mod gui { pub(crate) use crate::readonly_v2; }
#[path = "D:/rust_projects/lab-runtime/scripts/support/native-glow-device.rs"] mod device;
fn main() { fn send<T: Send>() {} send::<device::Device>(); }